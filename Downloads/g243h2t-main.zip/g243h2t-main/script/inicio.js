const btnTeste = document.querySelector("#teste");

btnTeste.onclick = ()=>{
    alert("Funcionou");
}